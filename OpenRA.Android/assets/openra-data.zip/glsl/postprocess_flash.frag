#version {VERSION}
#ifdef GL_ES
precision highp float;
precision highp int;
#endif

uniform float Blend;
uniform vec3 Color;
uniform sampler2D SourceTexture;
out vec4 fragColor;

void main()
{
	vec4 c = texelFetch(SourceTexture, ivec2(gl_FragCoord.xy), 0);
	fragColor = mix(c, vec4(Color, c.a), Blend);
}
